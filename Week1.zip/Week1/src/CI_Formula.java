
public class CI_Formula {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double p = 1200;
	    double r = 5.4;
	    double t = 2; 

			/* Calculate compound interest */
			double CI = p * 
						(Math.pow((1 + r / 100), t)); 
			
			System.out.println("Compound Interest is "+ CI); 
		} 
	
	}


