
public class SwapNum {

	
	
	static void swapValuesUsingThirdVariable(int m, int n)
    {
    
        int x = m;
        m = n;
        n = x;
        System.out.println("Value of m is " + m
                           + " and Value of n is " + n);
    }
 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		        // Random values
		        int m = 9, n = 5;
		 
		   
		        swapValuesUsingThirdVariable(m, n);
		    
	}

}


